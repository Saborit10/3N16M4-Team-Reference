## Convensiones Generales Para Clases que Manipulan Grafos
* Se define una estructura edge que representa una arista del grafo
* Se usa un arreglo de vectores de tipo edge para representar el grafo globalmente.
* Se define en la clase del algoritmo, un puntero a la lista de adyacencia del grafo global.
